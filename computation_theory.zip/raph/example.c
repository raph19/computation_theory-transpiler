var x = 0; double;

void main(){
	for (i = 0; x == 9; i = i + 1){

		x = x + 3;
	};
	return;
	}
